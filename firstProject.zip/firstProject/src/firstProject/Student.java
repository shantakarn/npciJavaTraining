package firstProject;

public class Student extends User {
	private String course;
	private String college;
	
	public void setStudentDetails(String name, String city, int birthYear, String college, String course) {
		this.setUserDetails(name, city, birthYear);
		this.college=college;
		this.course=course;
	}
	
	public void printStudentDetails() {
		this.printUserDetails();
		System.out.println("College: "+college);
		System.out.println("Course: "+course);
	}
	
}
