package firstProject;

public class App {
public static void main(String args[])
{
	
	Student student = new Student();
	student.setStudentDetails("Shanta","chennai",1999,"java","iter");
	student.printStudentDetails();
}
}
