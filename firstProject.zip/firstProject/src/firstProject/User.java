package firstProject;

public class User {
	private String name;
	private String city;
	private int birthYear;
	
	public void setUserDetails(String name,String city,int birthYear) {
		this.name= name;
		this.city=city;
		this.birthYear=birthYear;
	}
	
	public void printUserDetails(){
		System.out.println("Name: "+name);
		System.out.println("BirthYear: "+birthYear);
		System.out.println("City: "+city);
	}
	
}
