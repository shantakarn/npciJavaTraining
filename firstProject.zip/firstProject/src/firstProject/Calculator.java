package firstProject;

public class Calculator {
}
