package com.maven.mavenJavaProject;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages="com.maven.mavenJavaProject")
public class AppConfig {

}
