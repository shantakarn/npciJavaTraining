package com.maven.mavenJavaProject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */

public class App {
	
    public static void main( String[] args )
    {
    	
        System.out.println( "Hello World!" );
		/*
		 * UserClass userClass=new UserClass(1,"shanta",5.5);
		 * userClass.getUserDetails();
		 */
        
        
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        // to say the spring to collect all the objects from the AppConfig.class
       

    	UserClass userClass = (UserClass)applicationContext.getBean("userClass");
    	//new way to create object
    	userClass.getUserDetails();
    	
    	//example of Singleton pattern only spring follows this not java
//    	UserClass userClass1 = (UserClass)applicationContext.getBean("userClass");
//		System.out.println(userClass);
//		System.out.println(userClass1);
    	
    }
    
    
    
    
    
    
    
   
    
    
    
    
    
}
