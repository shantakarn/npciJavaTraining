package com.maven.mavenJavaProject;

import org.springframework.stereotype.Component;

@Component

public class UserDataValidationImpl implements UserDataValidation {

	@Override
	public String checkUserId(Integer uId) {
		if(uId != null && uId.toString().matches("\\d")) {
			return ("uId is correct") ;
		}
		else {
			return ("uId is not correct");
		}
	}

	@Override
	public String checkUserName(String name) {
		if(name != null && name.matches("[a-zA-Z0-9_]+") && (name.length()>=5 && name.length() <=20)) {
			return ("User Name is correct");
		}
		else {
			return ("User Name is not correct");
		}
	}

	@Override
	public String checkUserSalary(double salary) {
		if(salary > 0.0 &&  String.valueOf(salary).matches(("[0-9.]+"))) {
			return ("User Salary is correct");
		}
		else {
			return ("User Salary is not correct");
		}
	}
	
}
