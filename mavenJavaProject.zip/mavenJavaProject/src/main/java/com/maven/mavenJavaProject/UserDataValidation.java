package com.maven.mavenJavaProject;

import org.springframework.stereotype.Component;

@Component
public interface UserDataValidation {

	String checkUserId(Integer uId);

	String checkUserName(String name);

	String checkUserSalary(double salary);

}
