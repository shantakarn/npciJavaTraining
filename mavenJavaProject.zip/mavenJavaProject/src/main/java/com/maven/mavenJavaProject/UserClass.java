package com.maven.mavenJavaProject;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserClass {
	
//Property injection we can add @Qualifier before variable creation of classType
	//@Autowired
	//@Qualifier("advanceValidation") incase of ambiguity
	UserDataValidation userDataValidation;

	Integer uId;
	String name;
	double salary;
	
//constructor injection we can add @Qualifier in parameters
	
	//@Autowired
//	public UserClass(UserDataValidation userDataValidation) {
//		this.userDataValidation =userDataValidation;
//	}
	
	
//	setter injection  we can add @Qualifier in parameters
	@Autowired
	public void setUserClassValidation(UserDataValidation userDataValidation)
	{
		this.userDataValidation = userDataValidation;
	}

	
	public void getUserDetails() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter User Id: ");
		Integer uId = scanner.nextInt();
		String checkUserId= userDataValidation.checkUserId(uId);
		System.out.println("Enter User name: ");
		String name = scanner.next();
		String checkUserName= userDataValidation.checkUserName(name);
		System.out.println("Enter User salary: ");
		double salary = scanner.nextInt();
		String checkUserSalary= userDataValidation.checkUserSalary(salary);
		System.out.println("User Validation Done, and Results are: "+checkUserId 
				+" and " +checkUserName +" and "+checkUserSalary);
	}
	@Override
	public String toString() {
		return "UserClass [userDataValidation=" + userDataValidation + ", uId=" + uId + ", name=" + name + ", salary="
				+ salary + "]";
	}
	
	
}
