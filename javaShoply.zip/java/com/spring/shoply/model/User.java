package com.spring.shoply.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="users")
@Getter
@Setter
@NoArgsConstructor
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name ="name",nullable = false)
	private String name;
	
	@Column(name ="userName",nullable = false)
	private String userName;
	
	@Column(name ="password",nullable = false)
	private String password;
	
	@CreationTimestamp
	private LocalDateTime createAt;
	
	@UpdateTimestamp
	private LocalDateTime updatedAt;
	
	@Column(name ="roles")
	private String roles;

	public User(String name, String userName, String password, String roles) {
		super();
		this.name = name;
		this.userName = userName;
		this.password = password;
		this.roles = roles;
	}
	
	@OneToMany (mappedBy = "user",cascade = CascadeType.ALL)
	private List<CartItem> cartItems = new ArrayList<>();
}
