package com.spring.shoply.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.shoply.services.CartItemService;

@RestController
@RequestMapping("/api/v1/cartitem")
public class CartItemController {
	@Autowired
	private CartItemService cartItemService;
	
	@PostMapping("/addToCart")
	public String addToCart(@RequestBody Map<String, Long> item) {
		
		cartItemService.addToCart(item);
		return "ids";
		 
	}

}
