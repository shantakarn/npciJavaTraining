package com.spring.shoply.services;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.shoply.model.CartItem;
import com.spring.shoply.model.Product;
import com.spring.shoply.model.User;
import com.spring.shoply.repositories.CartItemRepository;
import com.spring.shoply.repositories.ProductRepository;
import com.spring.shoply.repositories.UserRepository;

@Service
public class CartItemService {
	@Autowired
	private CartItemRepository cartItemRepository;
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private UserRepository userRepository;
	
	public String addToCart(Map<String, Long> item) {
		Optional<Product> product = productRepository.findById(item.get("productid"));
		Optional<User> user = userRepository.findById(item.get("userid"));
		CartItem cartItem =new CartItem();
		cartItem.setProduct(product.get());
		cartItem.setUser(user.get());
		cartItem.setQuantity(item.get("quantity").intValue());
		cartItem.setPrice(item.get("price").intValue());
		
		cartItemRepository.save(cartItem);
		return"added to cart";
	}
}
