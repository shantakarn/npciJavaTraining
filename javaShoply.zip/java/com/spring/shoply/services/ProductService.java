package com.spring.shoply.services;

import java.util.List;
import java.util.Optional;

import org.antlr.v4.runtime.misc.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.shoply.model.Product;
import com.spring.shoply.repositories.ProductRepository;

@Service
public class ProductService {
	private ProductRepository productRepository;
	@Autowired
	public ProductService(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}
	public Product createProduct(Product product) {
		return productRepository.save(product);
	}
	public List<Product> getAllProduct(){
		return productRepository.findAll();
	}
	public Product getProductById(Long id) {
		Optional<Product> product= productRepository.findById(id);
		if(product.isPresent()) {
			return product.get();
		}
		
			throw new RuntimeException("No record for this id");
	}
	public Product getProductByName(String name) {
		return productRepository.getProductByName(name);
	}
	public Product updateProduct(Product product, Long id){
		Optional<Product> productOp= productRepository.findById(id); 
		if(productOp.isPresent()) 
		{
		Product productUpdate = productOp.get();
		productUpdate.setName(product.getName());
		productUpdate.setPrice(product.getPrice());
		productUpdate.setQuantity(product.getQuantity());
		return productRepository.save(productUpdate);
		}
		throw new RuntimeException("no update");
	}
	public void deleteProduct(Long id) {
		Optional<Product> productOp= productRepository.findById(id); 
		if(productOp.isPresent()) 
		{
		productRepository.deleteById(id);
		}
		else {
		throw new RuntimeException("no record");
	}}
	
	
	
}
