package com.spring.shoply.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.shoply.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{

	Product getProductByName(String name);

}
