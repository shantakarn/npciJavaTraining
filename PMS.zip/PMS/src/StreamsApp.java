import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamsApp {

	public static void main(String args[]) {
		Integer arr[]= {40,1,3,5};
		Stream<Integer> streamArray = Arrays.stream(arr);
		System.out.println(streamArray.reduce((a,b)->a+b).get());
		
		//System.out.println(streamArray.sorted().collect(Collectors.toList()));
		//streamArray.sorted((a,b) -> b-a).forEach(p->System.out.println(p));
		
		
		List<String> list1 = Arrays.asList("car","cat","cow");
		List<String> list2 = Arrays.asList("fan","fish","fox");
		List<String> list3 = Arrays.asList("apple","app","ant");
		List<List<String>> mainList = new ArrayList<>();
		mainList.add(list1);
		mainList.add(list2);
		mainList.add(list3);
		System.out.println(mainList);
		/*
		 * mainList.stream().flatMap((n)->{return ((Collection<Integer>) n).stream();})
		 * .forEach(n->System.out.println(n));
		 */
		List<String> newList = mainList.stream()
				.flatMap(n-> n.stream())
				.filter(n->n.charAt(0)=='c')
				.collect(Collectors.toList());
		System.out.println("newList "+newList);
	}
}
