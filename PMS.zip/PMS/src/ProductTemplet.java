
public interface ProductTemplet {
	int calculateProductPrice(int a, int b);
	default void productTagline() {
		System.out.println("We are Amozone");
	}
	static void productBrandline() {
		System.out.println("We are Nike");
	}	
}
