import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Stream;

public interface ProductApp {
	public static void main(String args[]) {
		Scanner scanner =new Scanner(System.in);
		ArrayList<Product> object= new ArrayList<>();
		for(int i=0;i<2;i++){
		System.out.println("Enter the Product Name: ");
		String name= scanner.next();
		System.out.println("Enter the Product Price: ");
		int price= scanner.nextInt();
		System.out.println("Enter the Product Category: ");
		String category=scanner.next();
		System.out.println("Enter the Product Quantity: ");
		int quantity=scanner.nextInt();
		Product product= new Product(name,price,category,quantity);
		
		object.add(product);
		}
		//creating stream of ArrayList
		Stream<Product> productStream =object.stream();
		System.out.println("Enter the name to search:");
		String productName = scanner.next();
		
		productStream.filter((p)->p.getName().equalsIgnoreCase(productName)).forEach(p->System.out.println(p));
		productStream.sorted((p1,p2)->p1.getPrice()-p2.getPrice()).forEach(p->System.out.println(p));
		
		/*
		 * for(int i=0;i<object.size();i++) { System.out.println(object.get(i)); }
		 */
}
}
