public class Product{
	private String name;
	public String getName() {
		return name;
	}

	public int getPrice() {
		return price;
	}

	public String getCatogory() {
		return catogory;
	}

	public int getQuantity() {
		return quantity;
	}

	private int price;
	private String catogory;
	private int quantity;
	
	  public Product(String name, int price, String catogory, int quantity) {
		this.name = name;
		this.price = price;
		this.catogory = catogory;
		this.quantity = quantity;
	}

	@Override
	  public String toString() {
		  return "Product [name=" + name +
	  ", price=" + price + ", catogory=" + catogory + ", quantity=" + quantity + "]"; 
		  }
	 
	
	
}
