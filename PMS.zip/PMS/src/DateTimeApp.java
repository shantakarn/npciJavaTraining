import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateTimeApp {
	public static void main(String args[]) {
		LocalDate currentDate = LocalDate.now();
		System.out.println("currentDate "+currentDate);
		LocalDate customDate = LocalDate.of(2024, 1, 3);
		System.out.println("customDate "+customDate);
		//string format to localdate 
		LocalDate parsedDate = LocalDate.parse("2023-01-02");
		System.out.println("day of year"+ parsedDate.getDayOfYear());
		System.out.println("Month value "+parsedDate.getMonthValue());
		System.out.println("Month "+parsedDate.getMonth());
		System.out.println(currentDate.minusDays(3));
		System.out.println(currentDate.plusWeeks(34));
		System.out.println(currentDate.isAfter(parsedDate));
		System.out.println(currentDate.isBefore(parsedDate));
		System.out.println(currentDate.isEqual(parsedDate));
		System.out.println(currentDate.isLeapYear());
		
		LocalTime currentTime = LocalTime.now();
		System.out.println("localTime "+currentTime);
		LocalTime customTime = LocalTime.of(14, 30, 25);
		System.out.println("customTime "+customTime);
		//string format to localTime 
		LocalTime parsedTime = LocalTime.parse("10:25:20");
		System.out.println("parsed Date "+ parsedTime);
		System.out.println(currentTime.getHour());
		System.out.println(currentTime.getMinute());
		System.out.println(currentTime.plusHours(4));
		System.out.println(currentTime.minusMinutes(60));
		System.out.println(currentTime.isAfter(customTime));
		System.out.println(currentTime.isBefore(customTime));
		
		LocalDateTime currentDT = LocalDateTime.now();
		System.out.println("current DateTime "+currentDT);
		LocalDateTime customDT = LocalDateTime.of(2024,11,30, 12,25,30);
		System.out.println("custom DT "+customDT);
		//string format to localDateTime 
		LocalDateTime parsedDT= LocalDateTime.parse("2024-11-25T12:29:23");
		System.out.println("parsed DT "+parsedDT);
		System.out.println(currentDT.getDayOfMonth());
		System.out.println(currentDT.getDayOfWeek());
		
		ZonedDateTime zoneDT = ZonedDateTime.now();
		System.out.println("zoneDT "+zoneDT);
		System.out.println("Zone ID "+zoneDT.getZone());
		//ZoneId.getAvailableZoneIds().forEach(n->System.out.println(n));
		ZonedDateTime customZoneDT = ZonedDateTime.of(2024, 11, 29, 14, 30, 25, 23, ZoneId.of("Asia/Calcutta"));
		System.out.println("customZoneDT "+customZoneDT);
		
		Instant instant = Instant.now();
		System.out.println("Instant "+ instant);
	}	
}
