package com.spring.jpajavademo;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;



@SpringBootApplication
public class JpaJavaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaJavaDemoApplication.class, args);
	}
	@Bean
	CommandLineRunner commandLineRunner(CustomerRepository customerRepository, AdressRepository adressRepository,
			ProductRepository productRepository, CustomerProductRepository customerProductRepository) {
		return args ->{
			/*
			//insert data
			CustomerModel customerModel = new CustomerModel("shanta","ashanta@gfm.vom","chennai",3);
			customerRepository.save(customerModel);//save returns customerModel i.e created.
			System.out.println("Inserted data "+customerRepository.save(customerModel));// to see the returned object
			*/
			/*
			// to delete
			CustomerModel customerModel = new CustomerModel();
			customerModel.setId(3L);
			customerRepository.delete(customerModel);//
			*/
			/*
			//to update
			Optional<CustomerModel> customerModel = customerRepository.findById(4L) ;//fetch record by id and it returns optional
			if(customerModel.isPresent()) {
				CustomerModel customer= customerModel.get();
				customer.setCity("Mumbai");
				customerRepository.save(customer);
				
			}*/
			/*
			//for bulk insert
			CustomerModel customerModel1 = new CustomerModel("shanta","ashanta@gfm.vom","chennai",3);
			CustomerModel customerModel2 = new CustomerModel("sheetal","sheetal@gfm.vom","bangalore",4);
			customerRepository.saveAll(List.of(customerModel1,customerModel2));
			*/
			/*
			//to fetch all the data
			List<CustomerModel> customerModels = customerRepository.findAll();
			System.out.println(customerModels);
			*/
			
			/*
			//customer and address relation insert data 
			
			CustomerModel customerModel1 = new CustomerModel("shanta","ashanta@gfm.vom","chennai",3);
			Adress adress = new Adress(21,"sai ganesh","npcistreet","vellore",12321);
			Adress adress1 = new Adress(22,"sai","nstreet","velore",12321);
			
			adress.setCustomerModel(customerModel1);
			adress1.setCustomerModel(customerModel1);
			customerModel1.getAddressList().add(adress);
			customerModel1.getAddressList().add(adress1);
			customerRepository.save(customerModel1);
			*/
			
			/*
			//update address for existing customer
			Optional<CustomerModel> customerModel = customerRepository.findById(1L);
			Adress adress = new Adress(11,"ganesh","npcistreet","vere",12321);
			if(customerModel.isPresent()) {
				CustomerModel customer= customerModel.get();
				adress.setCustomerModel(customer);
				adressRepository.save(adress);
			}
			*/
			/*
			 //to insert data in product and customer
			CustomerModel customerModel = new CustomerModel("sai","sai@gfm.vom","chennai",4);
			CustomerModel customerModel2 = new CustomerModel("sumit","sumit@gfm.vom","chennai",3);
			customerRepository.saveAll(List.of(customerModel,customerModel2));
			
			ProductModel productModel1 = new ProductModel("cream",45);
			ProductModel productModel2 = new ProductModel("car",4500);
			ProductModel productModel3 = new ProductModel("box",470);
			ProductModel productModel4 = new ProductModel("ring",4522);
			productRepository.saveAll(List.of(productModel1,productModel2,productModel3,productModel4));
			*/
			
			Optional<CustomerModel> customerModel = customerRepository.findById(3L);
			Optional<ProductModel> productModel = productRepository.findById(1L);
			CustomerProduct customerProduct = new CustomerProduct(1);
			if(customerModel.isPresent() && productModel.isPresent()) {
				CustomerModel customer= customerModel.get();
				ProductModel product = productModel.get();
				customerProduct.setCustomerModel(customer);
				customerProduct.setProductModel(product);
				customerProductRepository.save(customerProduct);
				
			}
			
			
		};
}
}
