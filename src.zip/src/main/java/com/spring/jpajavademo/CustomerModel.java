package com.spring.jpajavademo;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.bytecode.internal.bytebuddy.PrivateAccessorException;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="customers")
public class CustomerModel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name="name", nullable = false)
	private String name;
	@Column(name="email", nullable = false)
	private String email;
	@Column(name="city",nullable = false)
	private String city;
	@Column(name="age",nullable = false)
	private int age;
	
	//constructor
	public CustomerModel() {
		super();
	}
	//ignore id because its auto increment
	public CustomerModel(String name, String email, String city, int age) {
		super();
		this.name = name;
		this.email = email;
		this.city = city;
		this.age = age;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	//one customer will have multiple Address, thatswhy list of address, 
		//whose is gonna take foreign key otherwise create another table, foreignkey is mapped here
		//mapped by means making one class as owner
		@OneToMany(mappedBy = "customerModel",cascade = CascadeType.ALL)
		private List<Adress> addressList =new ArrayList<Adress>();
		public List<Adress> getAddressList() {
			return addressList;
		}
		public void setAddressList(List<Adress> addressList) {
			this.addressList = addressList;
		}
		
		//one customer will have multiple product, so productlist
		//@OneToMany
		//@ManyToMany(mappedBy = "customerList",cascade = CascadeType.ALL)
		@OneToMany(mappedBy = "customerModel",cascade = CascadeType.ALL)
		private List<CustomerProduct> customerProductList = new ArrayList<>(); 
		
	
	public List<CustomerProduct> getCustomerProductList() {
			return customerProductList;
		}
		public void setCustomerProductList(List<CustomerProduct> customerProductList) {
			this.customerProductList = customerProductList;
		}
	//print Object
	@Override
	public String toString() {
		return "CustomerModel [id=" + id + ", name=" + name + ", email=" + email + ", city=" + city + ", age=" + age
				+ "]";
	}
	
	
	
	
	
}
