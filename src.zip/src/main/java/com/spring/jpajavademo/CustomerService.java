package com.spring.jpajavademo;

import org.springframework.beans.factory.annotation.Autowired;

public class CustomerService {
	@Autowired
	private CustomerRepository customerRepository;
	public void createCustomerService() {
	}
}
