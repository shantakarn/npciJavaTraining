package com.spring.jpajavademo;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="products")
public class ProductModel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name="name", nullable=false)
	private String name;
	@Column(name="price", nullable=false)
	private Integer price;
	
	//constructor
	public ProductModel() {
		super();
	}
	public ProductModel(String name, Integer price) {
		super();
		this.name = name;
		this.price = price;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
	
	//one product will have multiple customer, so customerlist, mapped by means making one class as owner 
	//@OneToMany(mappedBy = "productList")
	//@ManyToMany 
	//@JoinTable(name="customer_product",
	//joinColumns = @JoinColumn(name="product_id"),
	//inverseJoinColumns= @JoinColumn(name="customer_id"))
	@OneToMany(mappedBy = "productModel",cascade = CascadeType.ALL)
	private List<CustomerProduct> customerProductList =new ArrayList<>();
	
	
	public List<CustomerProduct> getCustomerProductList() {
		return customerProductList;
	}
	public void setCustomerProductList(List<CustomerProduct> customerProductList) {
		this.customerProductList = customerProductList;
	}
	@Override
	public String toString() {
		return "ProductModel [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
	
	
	
}
